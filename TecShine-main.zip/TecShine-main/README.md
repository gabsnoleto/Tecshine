

# Manual de Instalação

Acompanhe o tutorial para instalar a solução TecShine

# 1º - Instalar o sensor

- Instale os sensores no lugares que desejar _(recomendamos entradas de salas)_, e conecte-os em sua rede

# 2º - Download do sistema 

- Faça o download da <a href="https://github.com/swtt-pch/TecShine/archive/refs/heads/main.zip">nossa solução</a> no nosso repositório do giihub

- O arquivo virá no formato .rar. Extraia no lugar onde desejar. 

# 3º - Inicialização do sistema

- Após extrair, abra a pasta e execute o arquivo "abrir.bat"

# 4º - Prontinho

- Agora é só usar o sistema normalmente!
